# Customized SummaryYou source package

Base project: `talosross/SummaryYou`
Imported source archive revision: `1ead5e0f63115dd8799a1dff4d2763656f44b231`
License: GPL-3.0; see `LICENSE.txt`. This package retains the upstream license and project attribution.

## Changes in this package

1. Added Android app-language locales `ur` (Urdu) and `ur-Latn` (Roman Urdu).
2. Added Urdu and Roman Urdu resource strings for core screens and status messages. Other untranslated strings fall back to the upstream English resources.
3. Added output-language mapping so `ur` asks the model for Urdu script and `ur-Latn` explicitly asks for Roman Urdu in Latin letters.
4. Strengthened the summarization prompt for fidelity, full coverage, idiomatic Urdu, accurate handling of quoted mantras/ritual steps, uncertainty, timestamps, and no fabricated fact-check claims.
5. Bundled the prompt in `app/src/main/assets/prompts/summarize.json` and changed the app to load that version locally rather than relying on a mutable GitHub raw URL at runtime.
6. Added unit tests for Urdu and Roman Urdu output-language mapping.

## Not included / not claimed

- No Whisper or other speech-to-text fallback for YouTube videos without captions.
- No independent source-search/fact-check pipeline.
- No guaranteed transcript chunking / complete processing of arbitrarily long videos.
- No embedded paid AI API key. Providers remain BYOK (or a user-operated Ollama server).

## Verification performed in this environment

- Original uploaded ZIP integrity: passed (`unzip -t`).
- JSON prompt parse: passed.
- Android XML well-formedness: checked by Python XML parser.
- Gradle/Kotlin Android compilation: **not run**. The project wrapper requires downloading Gradle 9.3.0, but network DNS access to `services.gradle.org` is unavailable in this environment. Android SDK availability is also not assumed. Therefore this package is source-modified but is not represented as a successfully built APK.

## Build command for a machine with Android SDK and internet access

```bash
./gradlew clean testFossDebugUnitTest assembleFossDebug
```

Expected APK output:
`app/build/outputs/apk/foss/debug/app-foss-debug.apk`
