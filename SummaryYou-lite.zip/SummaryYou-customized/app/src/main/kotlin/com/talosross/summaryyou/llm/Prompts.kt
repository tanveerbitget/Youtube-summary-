package com.talosross.summaryyou.llm

import ai.koog.prompt.dsl.Prompt
import kotlinx.serialization.Serializable

enum class SummaryLength {
    SHORT, MEDIUM, LONG
}

@Serializable
data class PromptConfig(
    val template: String,
    val lengthInstructions: Map<String, String>,
    val languageInstruction: LanguageInstructionConfig,
)

@Serializable
data class LanguageInstructionConfig(
    val useContentLanguage: String,
    val useAppLanguage: String,
)

/** Builds the fully-substituted system prompt text (shared by single-shot and chunked paths). */
fun buildPromptText(
    config: PromptConfig,
    length: SummaryLength,
    useContentLanguage: Boolean,
    appLanguage: String,
): String {
    val lengthInstruction = config.lengthInstructions[length.name]
        ?: config.lengthInstructions[SummaryLength.MEDIUM.name]
        ?: ""

    val languageInstruction = if (useContentLanguage) {
        config.languageInstruction.useContentLanguage
    } else {
        config.languageInstruction.useAppLanguage.replace("{{APP_LANGUAGE}}", appLanguage)
    }

    return config.template
        .replace("{{LENGTH_INSTRUCTION}}", lengthInstruction)
        .replace("{{LANGUAGE_INSTRUCTION}}", languageInstruction)
}

fun createSummarizationPrompt(
    config: PromptConfig,
    length: SummaryLength,
    useContentLanguage: Boolean,
    appLanguage: String,
): Prompt {
    return Prompt.build("summarizer-prompt") {
        system(buildPromptText(config, length, useContentLanguage, appLanguage))
    }
}
/** Returns an explicit output-language instruction label for the selected app locale. */
fun getSummaryLanguageName(locale: java.util.Locale): String = when {
    locale.language == "ur" && locale.script.equals("Latn", ignoreCase = true) ->
        "Roman Urdu (Urdu written in Latin/English letters; do not use Urdu/Arabic script)"
    locale.language == "ur" ->
        "Urdu (Pakistani Urdu; write using Urdu script)"
    else -> locale.getDisplayLanguage(java.util.Locale.ENGLISH)
}
