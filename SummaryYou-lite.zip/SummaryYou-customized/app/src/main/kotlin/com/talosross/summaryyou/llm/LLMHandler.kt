package com.talosross.summaryyou.llm

import ai.koog.agents.core.agent.AIAgent
import ai.koog.agents.core.agent.config.AIAgentConfig
import ai.koog.agents.core.agent.entity.AIAgentGraphStrategy
import ai.koog.agents.core.dsl.builder.forwardTo
import ai.koog.agents.core.dsl.builder.strategy
import ai.koog.agents.core.dsl.extension.nodeExecuteSingleTool
import ai.koog.agents.core.dsl.extension.nodeLLMRequest
import ai.koog.agents.core.environment.SafeTool
import ai.koog.agents.core.tools.ToolRegistry
import ai.koog.prompt.executor.clients.anthropic.AnthropicClientSettings
import ai.koog.prompt.executor.clients.anthropic.AnthropicLLMClient
import ai.koog.prompt.executor.clients.anthropic.AnthropicModels
import ai.koog.prompt.executor.clients.dashscope.DashscopeClientSettings
import ai.koog.prompt.executor.clients.dashscope.DashscopeLLMClient
import ai.koog.prompt.executor.clients.dashscope.DashscopeModels
import ai.koog.prompt.executor.clients.deepseek.DeepSeekClientSettings
import ai.koog.prompt.executor.clients.deepseek.DeepSeekLLMClient
import ai.koog.prompt.executor.clients.deepseek.DeepSeekModels
import ai.koog.prompt.executor.clients.google.GoogleClientSettings
import ai.koog.prompt.executor.clients.google.GoogleLLMClient
import ai.koog.prompt.executor.clients.google.GoogleModels
import ai.koog.prompt.executor.clients.mistralai.MistralAIClientSettings
import ai.koog.prompt.executor.clients.mistralai.MistralAILLMClient
import ai.koog.prompt.executor.clients.mistralai.MistralAIModels
import ai.koog.prompt.executor.clients.openai.OpenAIClientSettings
import ai.koog.prompt.executor.clients.openai.OpenAILLMClient
import ai.koog.prompt.executor.clients.openai.OpenAIModels
import ai.koog.prompt.executor.clients.openrouter.OpenRouterClientSettings
import ai.koog.prompt.executor.clients.openrouter.OpenRouterLLMClient
import ai.koog.prompt.executor.clients.openrouter.OpenRouterModels
import ai.koog.prompt.executor.llms.SingleLLMPromptExecutor
import ai.koog.prompt.executor.model.PromptExecutor
import ai.koog.prompt.executor.ollama.client.OllamaClient
import ai.koog.prompt.llm.OllamaModels
import ai.koog.prompt.message.Message
import android.content.Context
import io.ktor.client.HttpClient
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import com.talosross.summaryyou.UserPreferencesRepository
import com.talosross.summaryyou.llm.tools.Article
import com.talosross.summaryyou.llm.tools.ArticleExtractorTool
import com.talosross.summaryyou.llm.tools.BiliBiliSubtitleTool
import com.talosross.summaryyou.llm.tools.BiliBiliVideo
import com.talosross.summaryyou.llm.tools.File
import com.talosross.summaryyou.llm.tools.FileExtractorTool
import com.talosross.summaryyou.llm.tools.YouTubeTranscript
import com.talosross.summaryyou.llm.tools.YouTubeTranscriptTool
import com.talosross.summaryyou.model.ExtractedContent
import com.talosross.summaryyou.model.SummaryData
import com.talosross.summaryyou.model.SummaryException
import com.talosross.summaryyou.model.SummarySource
import kotlinx.serialization.json.Json
import java.util.Locale

@Serializable
data class SummaryOutput(
    override val title: String,
    override val author: String,
    override val summary: String,
    val sourceLink: String? = null,
    // TODO: just use SummarySource
    val isYoutubeLink: Boolean,
    val isBiliBiliLink: Boolean,
    val length: SummaryLength,
) : SummaryData

class LLMHandler(
    private val userPreferencesRepository: UserPreferencesRepository,
    context: Context,
    private val httpClient: HttpClient,
) {
    private val appContext = context.applicationContext
    private val fileExtractorTool: FileExtractorTool = FileExtractorTool(context)
    private val articleExtractorTool = ArticleExtractorTool(httpClient)
    private val youTubeTranscriptTool = YouTubeTranscriptTool(httpClient)
    private val bilibiliSubtitleTool = BiliBiliSubtitleTool(httpClient, userPreferencesRepository)

    private var _promptConfig: PromptConfig? = null
    private val promptConfigMutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true }

    private suspend fun getPromptConfig(): PromptConfig {
        _promptConfig?.let { return it }
        return promptConfigMutex.withLock {
            _promptConfig ?: fetchPromptConfig().also { _promptConfig = it }
        }
    }

    private suspend fun fetchPromptConfig(): PromptConfig {
        // Load the prompt shipped with the app first. This keeps summaries usable
        // when GitHub is unavailable and ensures the language/accuracy rules match
        // this exact app version instead of silently depending on a mutable remote file.
        return withContext(kotlinx.coroutines.Dispatchers.IO) {
            appContext.assets.open("prompts/summarize.json").bufferedReader().use { reader ->
                json.decodeFromString(PromptConfig.serializer(), reader.readText())
            }
        }
    }

    /**
     * Extract content locally from any source type, without involving an LLM.
     * Used by the proxy path to extract content before sending to the Cloudflare Worker.
     */
    suspend fun extractContent(source: SummarySource): ExtractedContent {
        return when (source) {
            is SummarySource.Article ->
                articleExtractorTool.execute(Article(source.url))
            is SummarySource.Video -> {
                if (YouTubeTranscriptTool.isYouTubeLink(source.url)) {
                    youTubeTranscriptTool.execute(YouTubeTranscript(source.url))
                } else if (BiliBiliSubtitleTool.isBiliBiliLink(source.url)) {
                    bilibiliSubtitleTool.execute(BiliBiliVideo(source.url))
                } else {
                    throw SummaryException.InvalidLinkException()
                }
            }
            is SummarySource.Document ->
                fileExtractorTool.execute(File(source.uri))
            is SummarySource.Text ->
                ExtractedContent(title = "Text Input", author = "Unknown", content = source.content)
            is SummarySource.None ->
                throw SummaryException.NoContentException()
        }
    }

    suspend fun getSummarizationAgent(
        provider: AIProvider,
        apiKey: String,
        baseUrl: String? = null,
        model: String? = null,
        summaryLength: SummaryLength = SummaryLength.MEDIUM,
        useContentLanguage: Boolean,
        appLanguage: Locale,
    ): AIAgent<SummarySource, SummaryOutput> {
        val executor = createExecutor(provider, apiKey, baseUrl, appLanguage)
        val llmModel = resolveModel(provider, model)

        val articleToolRegistry = ToolRegistry { tool(articleExtractorTool) }
        val youtubeToolRegistry = ToolRegistry { tool(youTubeTranscriptTool) }
        val bilibiliToolRegistry = ToolRegistry { tool(bilibiliSubtitleTool) }
        val fileToolRegistry = ToolRegistry { tool(fileExtractorTool) }
        val tools =
            articleToolRegistry + youtubeToolRegistry + bilibiliToolRegistry + fileToolRegistry

        val lang = getSummaryLanguageName(appLanguage)
        val agentConfig = AIAgentConfig(
            prompt = createSummarizationPrompt(getPromptConfig(), summaryLength, useContentLanguage, lang),
            model = llmModel,
            maxAgentIterations = 10,
        )

        return AIAgent(
            promptExecutor = executor,
            strategy = createSummarizationStrategy(
                articleExtractorTool,
                youTubeTranscriptTool,
                fileExtractorTool,
                summaryLength,
                executor,
                llmModel,
                useContentLanguage,
                lang,
            ),
            agentConfig = agentConfig,
            toolRegistry = tools
        )
    }

    private fun resolveModel(provider: AIProvider, modelName: String?): ai.koog.prompt.llm.LLModel {
        return modelName?.takeIf { it.isNotBlank() }?.let { name ->
            provider.models.find { it.id == name } ?: CustomLLModel(provider, name).toLLModel()
        } ?: when (provider) {
            AIProvider.INTEGRATED -> GoogleModels.Gemini2_5Flash
            AIProvider.OPENAI -> OpenAIModels.Chat.GPT4oMini
            AIProvider.GEMINI -> GoogleModels.Gemini2_5Flash
            AIProvider.CLAUDE -> AnthropicModels.Sonnet_3_5
            AIProvider.DEEPSEEK -> DeepSeekModels.DeepSeekChat
            AIProvider.MISTRAL -> MistralAIModels.Chat.MistralMedium31
            AIProvider.QWEN -> DashscopeModels.QWEN_FLASH
            AIProvider.OLLAMA -> OllamaModels.Alibaba.QWQ
            AIProvider.OPEN_ROUTER -> OpenRouterModels.Claude3Sonnet
        }
    }

    private fun createExecutor(
        provider: AIProvider,
        apiKey: String,
        baseUrl: String?,
        appLanguage: Locale,
    ): PromptExecutor {
        return when (provider) {
            AIProvider.INTEGRATED -> throw IllegalStateException("INTEGRATED provider uses proxy, not a direct executor")
            AIProvider.OPENAI -> createOpenAIExecutor(apiKey, baseUrl)
            AIProvider.GEMINI -> createGeminiExecutor(apiKey, baseUrl)
            AIProvider.CLAUDE -> createClaudExecutor(apiKey, baseUrl)
            AIProvider.DEEPSEEK -> createDeepSeekExecutor(apiKey, baseUrl)
            AIProvider.MISTRAL -> createMistralExecutor(apiKey, baseUrl)
            AIProvider.QWEN -> createQwenExecutor(apiKey, baseUrl, appLanguage)
            AIProvider.OLLAMA -> createOllamaExecutor(baseUrl)
            AIProvider.OPEN_ROUTER -> createOpenRouterExecutor(apiKey, baseUrl)
        }
    }

    private suspend fun createAgentConfig(
        provider: AIProvider,
        modelName: String?,
        summaryLength: SummaryLength,
        useContentLanguage: Boolean,
        appLanguage: Locale,
    ): AIAgentConfig {
        val llmModel = modelName?.takeIf { it.isNotBlank() }?.let { name ->
            provider.models.find { it.id == name } ?: CustomLLModel(provider, name).toLLModel()
        } ?: when (provider) {
            AIProvider.INTEGRATED -> GoogleModels.Gemini2_5Flash // not used directly, proxy handles model
            AIProvider.OPENAI -> OpenAIModels.Chat.GPT4oMini
            AIProvider.GEMINI -> GoogleModels.Gemini2_5Flash
            AIProvider.CLAUDE -> AnthropicModels.Sonnet_3_5
            AIProvider.DEEPSEEK -> DeepSeekModels.DeepSeekChat
            AIProvider.MISTRAL -> MistralAIModels.Chat.MistralMedium31
            AIProvider.QWEN -> DashscopeModels.QWEN_FLASH
            AIProvider.OLLAMA -> OllamaModels.Alibaba.QWQ
            AIProvider.OPEN_ROUTER -> OpenRouterModels.Claude3Sonnet
        }

        val lang = getSummaryLanguageName(appLanguage)
        return AIAgentConfig(
            prompt = createSummarizationPrompt(getPromptConfig(), summaryLength, useContentLanguage, lang),
            model = llmModel,
            maxAgentIterations = 10,
        )
    }

    private fun createOpenAIExecutor(apiKey: String, baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { OpenAILLMClient(apiKey, settings = OpenAIClientSettings(baseUrl = it)) }
            ?: OpenAILLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private fun createGeminiExecutor(apiKey: String, baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { GoogleLLMClient(apiKey, settings = GoogleClientSettings(baseUrl = it)) }
            ?: GoogleLLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private fun createClaudExecutor(apiKey: String, baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { AnthropicLLMClient(apiKey, settings = AnthropicClientSettings(baseUrl = it)) }
            ?: AnthropicLLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private fun createDeepSeekExecutor(apiKey: String, baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { DeepSeekLLMClient(apiKey, settings = DeepSeekClientSettings(baseUrl = it)) }
            ?: DeepSeekLLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private fun createMistralExecutor(apiKey: String, baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { MistralAILLMClient(apiKey, settings = MistralAIClientSettings(baseUrl = it)) }
            ?: MistralAILLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private fun createQwenExecutor(
        apiKey: String,
        baseUrl: String?,
        appLanguage: Locale,
    ): PromptExecutor {
        // assume mainland china user if using simple chinese
        val isSimplifiedChinese = appLanguage.language == "zh" && appLanguage.script == "Hans"

        val finalBaseUrl = if (isSimplifiedChinese) {
            "https://dashscope.aliyuncs.com"
        } else {
            baseUrl
        }
        val client = finalBaseUrl?.takeIf { it.isNotBlank() }
            ?.let { DashscopeLLMClient(apiKey, settings = DashscopeClientSettings(baseUrl = it)) }
            ?: DashscopeLLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private fun createOllamaExecutor(baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { OllamaClient(baseUrl = it) }
            ?: throw IllegalArgumentException("Base URL is required for Ollama")

        return SingleLLMPromptExecutor(client)
    }

    private fun createOpenRouterExecutor(apiKey: String, baseUrl: String?): PromptExecutor {
        val client = baseUrl?.takeIf { it.isNotBlank() }
            ?.let { OpenRouterLLMClient(apiKey, settings = OpenRouterClientSettings(baseUrl = it)) }
            ?: OpenRouterLLMClient(apiKey)

        return SingleLLMPromptExecutor(client)
    }

    private suspend fun createSummarizationStrategy(
        articleExtractorTool: ArticleExtractorTool,
        youTubeTranscriptTool: YouTubeTranscriptTool,
        fileExtractorTool: FileExtractorTool,
        summaryLength: SummaryLength,
        executor: PromptExecutor,
        llmModel: ai.koog.prompt.llm.LLModel,
        useContentLanguage: Boolean,
        appLanguage: String,
    ): AIAgentGraphStrategy<SummarySource, SummaryOutput> {

        return strategy("summarization_router_strategy")
        {
            var extractedContent: ExtractedContent? = null
            var isYoutube = false
            var isBiliBili = false
            var sourceLink = ""

            val contentExtractorSubgraph by subgraph<SummarySource, String>("content_extractor") {
                val nodeExtractArticle by nodeExecuteSingleTool(tool = articleExtractorTool)
                val nodeExtractYoutube by nodeExecuteSingleTool(tool = youTubeTranscriptTool)
                val nodeExtractBiliBili by nodeExecuteSingleTool(tool = bilibiliSubtitleTool)
                val nodeExtractFile by nodeExecuteSingleTool(tool = fileExtractorTool)

                val nodePreparePlainText by node<String, ExtractedContent>("prepare_plain_text") { text ->
                    ExtractedContent("Text Input", "Unknown", text)
                }

                val nodePreLLMRequest by node<ExtractedContent, String>("trigger_summary_from_tool") {
                    extractedContent = it
                    "Content has been extracted. Summarize it based on the instructions."
                }

                val processToolResult = { it: SafeTool.Result<out ExtractedContent> ->
                    when (it) {
                        is SafeTool.Result.Success -> it.result
                        is SafeTool.Result.Failure -> throw SummaryException.fromMessage(it.message)
                    }
                }

                edge(
                    nodeStart forwardTo nodeExtractArticle
                            onCondition { it is SummarySource.Article }
                            transformed { source ->
                                val url = (source as SummarySource.Article).url
                                sourceLink = url
                                Article(url)
                            }
                )
                edge(
                    nodeStart forwardTo nodeExtractYoutube
                            onCondition { it is SummarySource.Video && YouTubeTranscriptTool.isYouTubeLink((it).url) }
                            transformed { source ->
                                val url = (source as SummarySource.Video).url
                                isYoutube = true
                                sourceLink = url
                                YouTubeTranscript(url)
                            }
                )
                edge(
                    nodeStart forwardTo nodeExtractBiliBili
                            onCondition { it is SummarySource.Video && BiliBiliSubtitleTool.isBiliBiliLink((it).url) }
                            transformed { source ->
                                val url = (source as SummarySource.Video).url
                                isBiliBili = true
                                sourceLink = url
                                BiliBiliVideo(url)
                            }
                )
                edge(
                    nodeStart forwardTo nodeExtractFile
                            onCondition { it is SummarySource.Document }
                            transformed { source -> File((source as SummarySource.Document).uri) }
                )
                edge(
                    nodeStart forwardTo nodePreparePlainText
                            onCondition { it is SummarySource.Text }
                            transformed { (it as SummarySource.Text).content })

                // Tool-based paths
                edge(nodeExtractArticle forwardTo nodePreLLMRequest transformed { processToolResult(it) })
                edge(nodeExtractYoutube forwardTo nodePreLLMRequest transformed { processToolResult(it) })
                edge(nodeExtractBiliBili forwardTo nodePreLLMRequest transformed { processToolResult(it) })
                edge(nodeExtractFile forwardTo nodePreLLMRequest transformed { processToolResult(it) })
                edge(nodePreLLMRequest forwardTo nodeFinish)

                // Plain text path
                edge(nodePreparePlainText forwardTo nodeFinish transformed {
                    extractedContent = it
                    it.content
                })
            }

            val nodeSummarizeText by nodeLLMRequest(
                "summarize_extracted_text",
                allowToolCalls = false,
            )

            val nodeCombineResult by node<Message.Response, SummaryOutput>("combine_result") { response ->
                val content = response.content
                if (content.isBlank() || content.startsWith("Error:", ignoreCase = true)) {
                    throw SummaryException.fromMessage(content)
                }
                SummaryOutput(
                    title = extractedContent?.title ?: "",
                    author = extractedContent?.author ?: "",
                    summary = content,
                    sourceLink = sourceLink,

                    isYoutubeLink = isYoutube,
                    isBiliBiliLink = isBiliBili,
                    length = summaryLength,
                )
            }


            edge(nodeStart forwardTo contentExtractorSubgraph)

            edge(contentExtractorSubgraph forwardTo nodeSummarizeText)

            edge(nodeSummarizeText forwardTo nodeCombineResult)

            edge(nodeCombineResult forwardTo nodeFinish)
        }
}
