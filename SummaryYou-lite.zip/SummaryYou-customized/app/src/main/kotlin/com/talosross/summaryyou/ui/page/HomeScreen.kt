package com.talosross.summaryyou.ui.page

import android.content.ClipData
import android.content.ContentValues
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import com.talosross.summaryyou.BuildConfig
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonMenu
import androidx.compose.material3.FloatingActionButtonMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MediumFlexibleTopAppBar
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.ToggleButton
import androidx.compose.material3.ToggleFloatingActionButton
import androidx.compose.material3.ToggleFloatingActionButtonDefaults.animateIcon
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.material3.animateFloatingActionButton
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.toClipEntry
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch
import com.talosross.summaryyou.R
import com.talosross.summaryyou.llm.SummaryLength
import com.talosross.summaryyou.llm.tools.getFileName
import com.talosross.summaryyou.model.SummaryException
import com.talosross.summaryyou.ui.Nav
import com.talosross.summaryyou.ui.component.SummaryCard
import com.talosross.summaryyou.vm.AppViewModel
import com.talosross.summaryyou.vm.SummaryViewModel


private object MimeTypes {
    const val PDF = "application/pdf"
    const val DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val PNG = "image/png"
    const val JPEG = "image/jpeg"
    const val JPG = "image/jpg"
    const val WEBP = "image/webp"

    val allSupported = arrayOf(PDF, DOCX, PNG, JPEG, JPG, WEBP)
}

/**
 * Helper function to extract image from clipboard and save it to a temporary file
 * Returns the URI of the saved image or null if no image is found
 */
private fun getImageFromClipboard(context: android.content.Context, clipData: ClipData?): Uri? {
    if (clipData == null) return null

    for (i in 0 until clipData.itemCount) {
        val item = clipData.getItemAt(i)
        val uri = item.uri

        // Check if the URI points to an image
        if (uri != null) {
            val mimeType = context.contentResolver.getType(uri)
            if (mimeType?.startsWith("image/") == true) {
                return uri
            }
        }
    }

    return null
}

@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalMaterial3ExpressiveApi::class,
    ExperimentalFoundationApi::class,
    ExperimentalLayoutApi::class
)
@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    onNav: (dest: Nav) -> Unit = {},
    appViewModel: AppViewModel,
    summaryViewModel: SummaryViewModel = hiltViewModel<SummaryViewModel>(),
) {
    var urlOrText by rememberSaveable { mutableStateOf("") }
    var documentFilename by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current // Hide cursor
    val focusRequester = remember { FocusRequester() } // Show cursor after removing

    val settings by appViewModel.settingsUiState.collectAsState()

    fun summarize() {
        focusManager.clearFocus()
        summaryViewModel.summarize(urlOrText,  settings)
    }

    val appStartAction by appViewModel.appStartAction.collectAsState()
    LaunchedEffect(appStartAction) {
        appStartAction.content?.let {
            summaryViewModel.clearCurrentSummary()
            documentFilename = null
            urlOrText = it
            if (appStartAction.autoTrigger) {
                summarize()
            }
            appViewModel.onStartActionHandled()
        }
    }

    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboard.current
    val haptics = LocalHapticFeedback.current

    val options = listOf(
        stringResource(id = R.string.short_length),
        stringResource(id = R.string.middle_length),
        stringResource(id = R.string.long_length)
    ) // Lengths
    val summarizationState by summaryViewModel.summarizationState.collectAsState()

    val isLoading = summarizationState.isLoading
    val summaryResult = summarizationState.summaryResult
    val error = summarizationState.error
    LaunchedEffect(summaryResult) {
        isPlaying = false
    }
    LaunchedEffect(error) {
        isPlaying = false
    }
    LaunchedEffect(error) {
        error?.let { when(it){
            is SummaryException.BiliBiliLoginRequiredException -> {
                onNav(Nav.Settings(highlight = "3rd-party-service"))
                summaryViewModel.clearCurrentSummary()
            }
        } }

    }

    val apiKey = settings.apiKey
    val showLength = settings.showLength
    val summaryLength = settings.summaryLength

    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
    val snackbarHostState = remember { SnackbarHostState() }

    val hasResult = summaryResult?.summary?.isNotEmpty() == true
    val isDirty = showLength && (summaryResult?.let { it.length != summaryLength } ?: false)

    val result = remember { mutableStateOf<Uri?>(null) }
    val filePickerLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            result.value = uri
            if (uri == null) return@rememberLauncherForActivityResult

            scope.launch {
                summaryViewModel.clearCurrentSummary()
                documentFilename = getFileName(context, uri)
                urlOrText = uri.toString()
            }
        }

    val imagePickerLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) return@rememberLauncherForActivityResult

            scope.launch {
                summaryViewModel.clearCurrentSummary()
                documentFilename = getFileName(context, uri)
                urlOrText = uri.toString()
            }
        }

    var cameraImageUri by remember { mutableStateOf<Uri?>(null) }
    val cameraLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                cameraImageUri?.let { uri ->
                    scope.launch {
                        summaryViewModel.clearCurrentSummary()
                        documentFilename = getFileName(context, uri)
                        urlOrText = uri.toString()
                    }
                }
            }
        }

    fun clearInput() {
        urlOrText = ""
        summaryViewModel.clearCurrentSummary()
        focusRequester.requestFocus()
        documentFilename = null
    }

    fun pasteFromClipboard() {
        clearInput()
        scope.launch {
            clipboard.getClipEntry()?.let { clipEntry ->
                val clipData = clipEntry.clipData

                // First, try to get an image from the clipboard
                val imageUri = getImageFromClipboard(context, clipData)
                if (imageUri != null) {
                    documentFilename = getFileName(context, imageUri)
                    urlOrText = imageUri.toString()
                } else {
                    // If no image, try to get text
                    val text = clipData.getItemAt(0).text
                    if (text != null) {
                        urlOrText = text.toString()
                    }
                }
            }
        }
    }

    val listState = rememberLazyListState()
    val fabVisible by remember { derivedStateOf { !listState.canScrollBackward } }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = { HomeTopAppBar(onNav = onNav, scrollBehavior = scrollBehavior) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButtons(
                fabVisible = fabVisible,
                onPaste = { pasteFromClipboard() },
                onSummarize = {
                    haptics.performHapticFeedback(HapticFeedbackType.Confirm)
                    summarize()
                },
                isLoading = isLoading,
                hasResult = hasResult,
                isDirty = isDirty,
                onShowSnackbar = { message ->
                    scope.launch {
                        snackbarHostState.showSnackbar(message)
                    }
                },
                onCancel = {
                    haptics.performHapticFeedback(HapticFeedbackType.Reject)
                    summaryViewModel.cancelSummarization()
                },
                onLaunchFilePicker = {
                    filePickerLauncher.launch(MimeTypes.allSupported)
                },
                onLaunchImagePicker = {
                    imagePickerLauncher.launch("image/*")
                },
                onLaunchCamera = {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "new_image.jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(
                            MediaStore.Images.Media.RELATIVE_PATH,
                            Environment.DIRECTORY_PICTURES
                        )
                    }
                    val uri = context.contentResolver.insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        values
                    )
                    uri?.let {
                        cameraImageUri = it
                        cameraLauncher.launch(it)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize(),
            contentPadding = innerPadding
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineMedium
                    )

                        InputSection(
                            urlOrText = urlOrText,
                            onUrlChange = { urlOrText = it },
                            onSummarize = { summarize() },
                            error = error,
                            apiKey = apiKey,
                            onClear = { clearInput() },
                            focusRequester = focusRequester,
                            documentFilename = documentFilename,
                            isLoading = isLoading,
                            onPaste = { pasteFromClipboard() },
                            developerMode = settings.developerMode
                        )

                    if (showLength) {
                        LengthSelector(
                            selectedIndex = summaryLength.ordinal,
                            onSelectedIndexChange = { appViewModel.setSummaryLength(SummaryLength.entries[it]) },
                            options = options,
                            enabled = !isLoading,
                        )
                    }

                    // Loading-Animation
                    if (isLoading) {
                        LinearWavyProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 5.dp)
                        )
                    }

                    summaryResult?.takeIf { it.summary.isNotEmpty() }?.let { summaryOutput ->
                        SummaryCard(
                            modifier = Modifier.padding(vertical = 15.dp),
                            isExpandedByDefault = true,
                            summary = summaryOutput,
                            onLongClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                scope.launch {
                                    clipboard.setClipEntry(
                                        ClipData.newPlainText(
                                            "User Input",
                                            summaryOutput.summary
                                        ).toClipEntry()
                                    )
                                }
                            },
                            onShowSnackbar = {
                                scope.launch { snackbarHostState.showSnackbar(it) }
                            },
                            isPlaying = isPlaying,
                            onPlayRequest = { isPlaying = !isPlaying }
                        )
                    }
                }
            }
        }
    }
}

