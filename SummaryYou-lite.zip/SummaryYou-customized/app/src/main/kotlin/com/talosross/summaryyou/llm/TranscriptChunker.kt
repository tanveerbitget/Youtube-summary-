package com.talosross.summaryyou.llm

import ai.koog.prompt.dsl.Prompt
import ai.koog.prompt.executor.model.PromptExecutor
import ai.koog.prompt.llm.LLModel
import kotlinx.coroutines.delay

/**
 * Splits long text into chunks at sentence boundaries so no sentence is cut in half.
 */
object TranscriptChunker {
    const val MAX_CHUNK_CHARS = 8000

    fun chunk(text: String, maxChars: Int = MAX_CHUNK_CHARS): List<String> {
        if (text.length <= maxChars) return listOf(text)
        val sentences = Regex("(?<=[.!?।])\\s+").split(text).filter { it.isNotBlank() }
        val chunks = mutableListOf<String>()
        val sb = StringBuilder()
        for (s in sentences) {
            if (sb.isNotEmpty() && sb.length + s.length + 1 > maxChars) {
                chunks.add(sb.toString().trim())
                sb.clear()
            }
            // Single sentence longer than maxChars: hard-split it
            if (s.length > maxChars) {
                if (sb.isNotEmpty()) { chunks.add(sb.toString().trim()); sb.clear() }
                var i = 0
                while (i < s.length) {
                    chunks.add(s.substring(i, minOf(i + maxChars, s.length)))
                    i += maxChars
                }
            } else {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(s)
            }
        }
        if (sb.isNotEmpty()) chunks.add(sb.toString().trim())
        return chunks
    }
}

/**
 * Map-reduce summarizer for long transcripts.
 * Each chunk is summarized independently (with retries), then all partial
 * summaries are combined into one final coherent summary in chronological order.
 */
class ChunkedSummarizer(
    private val executor: PromptExecutor,
    private val model: LLModel,
) {
    suspend fun summarizeLong(
        promptText: String,
        content: String,
        onProgress: ((done: Int, total: Int) -> Unit)? = null,
    ): String {
        val chunks = TranscriptChunker.chunk(content)
        if (chunks.size <= 1) {
            return requestOnce(promptText, content)
        }

        val partials = mutableListOf<String>()
        chunks.forEachIndexed { i, chunk ->
            val chunkPrompt = buildString {
                append(promptText)
                append("\n\n## Partial-Summary Task\nThis is section ")
                append(i + 1).append(" of ").append(chunks.size)
                append(" of a longer transcript, in original chronological order. ")
                append("Summarize ONLY this section faithfully. Do not invent content. ")
                append("Preserve names, numbers, dates, steps, warnings and exact quoted words (e.g. mantras) from this section.")
            }
            partials.add(requestOnce(chunkPrompt, chunk, retries = 3))
            onProgress?.invoke(i + 1, chunks.size)
        }

        val combined = buildString {
            append(promptText)
            append("\n\n## Combine Task\nBelow are partial summaries of consecutive sections of one long transcript, in chronological order. ")
            append("Combine them into ONE coherent final summary: remove repetition, keep chronological flow, ")
            append("and do not drop important details, names, numbers, warnings, steps, or exact quoted words from any section.")
        }
        val numbered = partials.mapIndexed { i, p -> "### Section ${i + 1}\n$p" }.joinToString("\n\n")
        return requestOnce(combined, numbered, retries = 3)
    }

    private suspend fun requestOnce(
        systemPrompt: String,
        userContent: String,
        retries: Int = 1,
    ): String {
        val prompt = Prompt.build("chunked-summarizer") {
            system(systemPrompt)
            user(userContent)
        }
        var lastError: Exception? = null
        repeat(retries) { attempt ->
            try {
                val response = executor.execute(prompt, model)
                val answer = response.firstOrNull()?.content?.trim().orEmpty()
                if (answer.isBlank()) throw IllegalStateException("Empty LLM response")
                return answer
            } catch (e: Exception) {
                lastError = e
                if (attempt < retries - 1) delay(1000L * (attempt + 1))
            }
        }
        throw lastError ?: IllegalStateException("LLM request failed")
    }
}
