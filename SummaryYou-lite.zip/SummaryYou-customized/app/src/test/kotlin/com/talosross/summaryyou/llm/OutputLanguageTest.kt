package com.talosross.summaryyou.llm

import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class OutputLanguageTest {
    @Test
    fun urduLocaleSelectsUrduScript() {
        assertTrue(getSummaryLanguageName(Locale.forLanguageTag("ur")).contains("Urdu"))
        assertTrue(getSummaryLanguageName(Locale.forLanguageTag("ur")).contains("Urdu script"))
    }

    @Test
    fun romanUrduLocaleRequiresLatinScript() {
        val language = getSummaryLanguageName(Locale.forLanguageTag("ur-Latn"))
        assertTrue(language.contains("Roman Urdu"))
        assertTrue(language.contains("Latin"))
    }
}
