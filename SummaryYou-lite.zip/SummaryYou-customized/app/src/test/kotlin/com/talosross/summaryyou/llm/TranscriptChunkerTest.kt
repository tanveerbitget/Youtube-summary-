package com.talosross.summaryyou.llm

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TranscriptChunkerTest {

    @Test
    fun `short text returns single chunk`() {
        val text = "This is short. It fits."
        assertEquals(listOf(text), TranscriptChunker.chunk(text, maxChars = 8000))
    }

    @Test
    fun `long text is split at sentence boundaries within limit`() {
        val sentence = "This is a test sentence number. "
        val text = sentence.repeat(500) // ~16000 chars
        val chunks = TranscriptChunker.chunk(text, maxChars = 1000)
        assertTrue(chunks.size > 1)
        chunks.forEach { assertTrue(it.length <= 1000) }
        // No sentence cut in half: every chunk boundary falls after a sentence end
        val rejoined = chunks.joinToString(" ")
        assertEquals(text.trim(), rejoined)
    }

    @Test
    fun `single very long sentence is hard split`() {
        val text = "a".repeat(2500)
        val chunks = TranscriptChunker.chunk(text, maxChars = 1000)
        assertEquals(3, chunks.size)
        assertEquals(text, chunks.joinToString(""))
    }

    @Test
    fun `empty text returns one empty chunk`() {
        assertEquals(listOf(""), TranscriptChunker.chunk("", maxChars = 100))
    }
}
